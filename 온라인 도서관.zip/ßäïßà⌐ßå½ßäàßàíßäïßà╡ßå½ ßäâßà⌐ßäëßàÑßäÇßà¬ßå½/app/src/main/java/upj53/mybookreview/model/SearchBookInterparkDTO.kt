package upj53.mybookreview.model

import com.google.gson.annotations.SerializedName

data class SearchBookInterparkDTO(
	@SerializedName("title")
	val title: String,
	@SerializedName("item")
	val books: List<BookInterpark>
)
