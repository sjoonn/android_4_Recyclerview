package upj53.mybookreview.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import upj53.mybookreview.databinding.RvBookNaverBinding
import upj53.mybookreview.model.BookNaver

class BookNaverAdapter(
	// 람다 표현식(자바/코틀린) 함수를 파라미터로 넘기는 것을 람다 표현식이라고 함.
	// (BookNaver) -> unit 에 뜻은
	// itemClickedListener 함수의 파라미터는 BookNaver 이고
	// itemClickedListener 함수의 리턴값은 없음을 unit이라고 말합니다.
	private val itemClickedListener: (BookNaver) -> Unit
) : ListAdapter<BookNaver, BookNaverAdapter.ViewHolder>(diffUtil) {

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		return ViewHolder( // rv_book_naver.xml 을 객체로 만든다. = inflate
			RvBookNaverBinding.inflate(LayoutInflater.from(parent.context), parent, false)
		)
	}

	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		holder.bind(currentList[position]) // 특정 포지션을 가져온다.
	}

	// inner class 란 안쪽에 들어있는 클래스 (클래스 안에 클래스를 쓰기 때문)

	inner class ViewHolder(   //생성자를 만들때 () 사용
		val binding: RvBookNaverBinding
	) : RecyclerView.ViewHolder(binding.root) {
		fun bind(book: BookNaver) { // bind = 묶다 xml 파일이랑 코틀린코드랑 묶는 함수
			binding.apply {  // apply 는 값을 자동으로 넣는 것이다.
				tvTitle.text = book.title
				tvAuthor.text = book.author
				tvDescription.text = book.description
				Glide
					.with(ivCover.context)
					.load(book.coverSmallUrl)
					.into(ivCover)
			}
		}
	}

	companion object {  // 자바에서 static 이라는 키워드가 있어서 변수를 다른 객체에서 공유해서 사용합니다. 코틀린에는 companion object 가 있습니다.
		val diffUtil = object : DiffUtil.ItemCallback<BookNaver>() {
			// 리싸이클러뷰에서 데이터가 많을 때 속도를 향상시켜주는 코드.
			// 리싸이클러뷰 리스트의 아이템이 같은 애들은 새로고침 안하고 다른 애들만 새로고침 하는 방법으로 속도를 향상시켰다(출처 : 구글)
			override fun areItemsTheSame(oldItem: BookNaver, newItem: BookNaver): Boolean {
				return oldItem == newItem
			}

			override fun areContentsTheSame(oldItem: BookNaver, newItem: BookNaver): Boolean {
				return oldItem.isbn == newItem.isbn
			}
		}
	}
}