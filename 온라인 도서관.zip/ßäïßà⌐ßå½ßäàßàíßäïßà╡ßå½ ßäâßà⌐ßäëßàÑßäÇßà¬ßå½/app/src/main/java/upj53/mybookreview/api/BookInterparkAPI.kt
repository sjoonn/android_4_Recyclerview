package upj53.mybookreview.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import upj53.mybookreview.model.BestSellerInterparkDTO
import upj53.mybookreview.model.SearchBookInterparkDTO

interface BookInterparkAPI {
	@GET("/api/search.api?output=json")
	fun getBooksByName(
		@Query("key") apiKey: String,
		@Query("query") keyword: String
	): Call<SearchBookInterparkDTO>

	@GET("/api/bestSeller.api?output=json&categoryId=100")
	fun getBestSellerBooks(
		@Query("key") apiKey: String
	): Call<BestSellerInterparkDTO>
}