package upj53.mybookreview.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import upj53.mybookreview.model.SearchBookInterparkDTO
import upj53.mybookreview.model.SearchBookNaverDTO

/*
Client ID
yFA9VJu4JIxrg_6ODIU4

Client Secret
otq3y_P8ZB
 */
interface BookNaverAPI {
	@GET("/v1/search/book.json")
	fun getBooksByName(
		@Header("X-Naver-Client-Id") id: String,
		@Header("X-Naver-Client-Secret") secretKey: String,
		@Query("query") keyword: String
	): Call<SearchBookNaverDTO>
}