package upj53.mybookreview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import upj53.mybookreview.adapter.BookInterparkAdapter
import upj53.mybookreview.adapter.BookNaverAdapter
import upj53.mybookreview.api.BookInterparkAPI
import upj53.mybookreview.api.BookNaverAPI
import upj53.mybookreview.databinding.ActivityMainBinding
import upj53.mybookreview.model.BestSellerInterparkDTO
import upj53.mybookreview.model.SearchBookInterparkDTO
import upj53.mybookreview.model.SearchBookNaverDTO

class MainActivity : AppCompatActivity() {
	private lateinit var binding: ActivityMainBinding
	private lateinit var adapterInterpark: BookInterparkAdapter
	private lateinit var adapterNaver: BookNaverAdapter

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		binding = ActivityMainBinding.inflate(layoutInflater)
		setContentView(binding.root)

		adapterInterpark = BookInterparkAdapter {
			Toast.makeText(this, "${it.title}", Toast.LENGTH_LONG).show()
		}
		adapterNaver = BookNaverAdapter {
			Toast.makeText(this, "${it.author}", Toast.LENGTH_LONG).show()
		}

		binding.rvInterpark.adapter = adapterInterpark
		binding.rvNaver.adapter = adapterNaver
		binding.etSearch.addTextChangedListener{
			val retrofitNaver = Retrofit.Builder()
				.baseUrl("https://openapi.naver.com")
				.addConverterFactory(GsonConverterFactory.create())
				.build()
			val bookNaverApi = retrofitNaver.create(BookNaverAPI::class.java)
			bookNaverApi.getBooksByName(
				"yFA9VJu4JIxrg_6ODIU4", //getString(R.string.naver_id),
				"otq3y_P8ZB", //getString(R.string.naver_secret_key),
				binding.etSearch.text.toString()
			).enqueue(object : Callback<SearchBookNaverDTO> {
				override fun onResponse(
					call: Call<SearchBookNaverDTO>,
					response: Response<SearchBookNaverDTO>
				) {
					response.body()?.let {
						it.books.forEach { book ->
//						Log.d("NAVER", "${book.title} (${book.author})")
							// 리싸이클러뷰에서 사용할 리스트를 저장해줍니다.
							adapterNaver.submitList(it.books)
						}
					}
				}

				override fun onFailure(call: Call<SearchBookNaverDTO>, t: Throwable) {
				}
			})
		}

		// 인터파크 API
		val retrofitInterpark = Retrofit.Builder()
			.baseUrl("https://book.interpark.com")
			.addConverterFactory(GsonConverterFactory.create())
			.build()
		val bookInterparkApi = retrofitInterpark.create(BookInterparkAPI::class.java)
		bookInterparkApi.getBooksByName(
			"B22D337FA6D578D0906A1BFC4B5AAA27500AF95D96222CD03502BA578769DF52",
			"교육 심리"
		).enqueue(object : Callback<SearchBookInterparkDTO> {
			override fun onResponse(
				call: Call<SearchBookInterparkDTO>,
				response: Response<SearchBookInterparkDTO>
			) {
				response.body()?.let {
					it.books.forEach { book ->
//						Log.d("INTERPARK", "${book.title} (${book.author})")
						adapterInterpark.submitList(it.books)
					}
				}
			}

			override fun onFailure(call: Call<SearchBookInterparkDTO>, t: Throwable) {
			}
		})
	}
}