package upj53.mybookreview.model

import com.google.gson.annotations.SerializedName

data class SearchBookNaverDTO(
	@SerializedName("items")
	val books: List<BookNaver>
)