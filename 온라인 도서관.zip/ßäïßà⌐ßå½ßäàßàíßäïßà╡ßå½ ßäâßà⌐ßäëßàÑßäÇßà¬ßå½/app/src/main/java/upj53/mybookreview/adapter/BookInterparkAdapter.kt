package upj53.mybookreview.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import upj53.mybookreview.databinding.RvBookInterparkBinding
import upj53.mybookreview.model.BookInterpark

class BookInterparkAdapter(
	private val itemClickedListener: (BookInterpark) -> Unit
) : ListAdapter<BookInterpark, BookInterparkAdapter.ViewHolder>(diffUtil) {

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		return ViewHolder(
			RvBookInterparkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
		)
	}

	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		holder.bind(currentList[position])
	}

	inner class ViewHolder(
		val binding: RvBookInterparkBinding
	) : RecyclerView.ViewHolder(binding.root) {
		fun bind(book: BookInterpark) {
			binding.apply {
				tvTitle.text = book.title
				tvAuthor.text = book.author
				Glide
					.with(ivCover.context)
					.load(book.coverSmallUrl)
					.into(ivCover)
			}
		}
	}

	companion object {
		val diffUtil = object : DiffUtil.ItemCallback<BookInterpark>() {
			override fun areItemsTheSame(oldItem: BookInterpark, newItem: BookInterpark): Boolean {
				return oldItem == newItem
			}

			override fun areContentsTheSame(oldItem: BookInterpark, newItem: BookInterpark): Boolean {
				return oldItem.isbn == newItem.isbn
			}
		}
	}
}
